module.exports = {
    port: 8081,
    Proxy: { '/': 'http://localhost:8080/'},
    navigator: false
}