<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FazeClan</title>
</head>
<style>
        body {
            font-family: tahoma, sans-serif;
            color: beige;
            background-color: #333333;
            background-image: url('<?php echo get_template_directory_uri(); ?>/pictures/background2.webp');
            background-size: cover;
            background-repeat: no-repeat;
        }
</style>
<header>
    <img class="fazelogo" src="<?php echo get_template_directory_uri(); ?>/pictures/Faze_Clan.webp" alt="">
    <div class="title" >
        <h1><?php echo get_the_title(); ?></h1>
        <div class="headercontent">
        <p><?php echo the_field('content1'); ?></p>
        </div>
    </div>
    <div class="navigatiebar">
        <nav>
            <?php
                $args = array (
                    'theme_location' =>'header-menu'
                );
            ?>

            <?php wp_nav_menu ( $args); ?>
        </nav>
    </div>

    <div class="navigatiebar2">
        <nav>
        <?php
                $args = array (
                    'theme_location' =>'extra-menu'
                );
            ?>
            <?php wp_nav_menu( $args); ?>
        </nav>
    </div>
    <?php wp_head() ?>
</header>

<body>



<div class="kader">
<p><?php echo the_field('content2'); ?></p>
<p><?php echo the_field('content3'); ?></p>
<p><?php echo the_field('content4'); ?></p>
</div>

<div class="javascript">
<h1>Informatieve Pagina?</h1>
    <button id="ja-button" class="beoordeling-button" onclick="handleBeoordeling(true)">Ja</button>
    <button id="nee-button" class="beoordeling-button" onclick="handleBeoordeling(false)">Nee</button>

  <script>
    function handleBeoordeling(isInformatief) {
      if (isInformatief) {
        document.getElementById('ja-button').innerHTML = 'Ja (Bedankt!)';
        document.getElementById('nee-button').disabled = true;
      } else {
        document.getElementById('nee-button').innerHTML = 'Nee (Jammer)';
        document.getElementById('ja-button').disabled = true;
      }
      console.log('Pagina was informatief:', isInformatief);
    }
  </script>
</div>


<footer class="footerback">
    <div >


        <?php
        function haaldatum($uc=   false) {
        $arr = ['', 'januari', 'februari', 'maart', 'april', 'mei',
        'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];
        
        return "laatst bijgewerkt op: ".
        $arr[intval (date('m'))]. "" .date(' Y');
        }
        ?>
    <div class=footertext>
<?php echo haaldatum(); ?>

<p><?php echo the_field('footer'); ?></p>
</div>
        
</div>
    </footer>
</body>
</html>